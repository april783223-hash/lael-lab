// usage.js — Firestore 버전
//
// 설계 원칙 (대화에서 정한 것, 변경 없음):
//   - 무료체험: 코치 1회 + 면접관 1회 (모드별 독립)
//   - 유료 기간권: 총 사용 횟수 무제한, 계정 공유 방지용 하루 세션 소프트캡만 적용
//   - "1회"는 메시지가 아니라 세션(연습 1판) 단위
//
// 컬렉션 구조:
//   trials/{uid}          { coachUsed, examinerUsed }
//   subscriptions/{uid}   { plan, startedAt, expiresAt, dailyCount, dailyDate, paymentProviderId }
//   sessions/{sessionId}  { userId, mode, createdAt, expiresAt }
//
// sessions는 Firestore의 TTL 정책 기능을 켜서 expiresAt 지난 문서를 자동 삭제하는 것을 권장한다.
// (Firebase 콘솔 > Firestore > TTL 정책 > 필드명 "expiresAt" 지정)

import { db } from "./auth.js";
import { FieldValue } from "firebase-admin/firestore";

const DAILY_SESSION_CAP = 10; // 유료 구독자의 하루 세션 상한 — 계정 공유 등 비정상 사용 방지용
const SESSION_TTL_MS = 2 * 60 * 60 * 1000; // 세션 유효 시간 2시간

function todayKey() {
  return new Date().toISOString().slice(0, 10); // 'YYYY-MM-DD'
}

function isActive(sub) {
  return !!sub && sub.expiresAt && sub.expiresAt.toDate() > new Date();
}

/**
 * 세션 시작을 시도한다. mode 선택 화면에서 "시작하기"를 누른 시점에 호출한다.
 */
export async function startSession(userId, mode) {
  if (!userId) return { allowed: false, reason: "no_user" };
  if (mode !== "coach" && mode !== "examiner") return { allowed: false, reason: "invalid_mode" };

  const subRef = db.collection("subscriptions").doc(userId);
  const subSnap = await subRef.get();
  const sub = subSnap.exists ? subSnap.data() : null;

  if (isActive(sub)) {
    // ---- 유료 구독자: 총량 제한 없음, 하루 세션 상한만 확인 ----
    const today = todayKey();
    const dailyCount = sub.dailyDate === today ? sub.dailyCount || 0 : 0;

    if (dailyCount >= DAILY_SESSION_CAP) {
      return { allowed: false, reason: "daily_cap_reached" };
    }

    await subRef.update({ dailyCount: dailyCount + 1, dailyDate: today });
  } else {
    // ---- 무료체험: 모드별 1회 ----
    const trialRef = db.collection("trials").doc(userId);
    const trialSnap = await trialRef.get();
    const trial = trialSnap.exists ? trialSnap.data() : {};
    const usedField = mode === "coach" ? "coachUsed" : "examinerUsed";

    if (trial[usedField]) {
      return { allowed: false, reason: "trial_exhausted", mode };
    }

    await trialRef.set({ [usedField]: true }, { merge: true });
  }

  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  const sessionRef = await db.collection("sessions").add({
    userId,
    mode,
    createdAt: FieldValue.serverTimestamp(),
    expiresAt,
  });

  return { allowed: true, sessionId: sessionRef.id };
}

/**
 * /api/chat이 호출될 때마다 세션이 유효한지만 확인한다 (사용량을 다시 깎지 않는다).
 */
export async function validateSession(sessionId, userId, mode) {
  if (!sessionId) return false;
  const snap = await db.collection("sessions").doc(sessionId).get();
  if (!snap.exists) return false;
  const data = snap.data();
  if (data.userId !== userId || data.mode !== mode) return false;
  return data.expiresAt.toDate() > new Date();
}

/**
 * 프론트가 "무료체험 남은 횟수"를 화면에 보여줄 때 쓰는 조회용 함수.
 */
export async function getTrialStatus(userId) {
  const subSnap = await db.collection("subscriptions").doc(userId).get();
  const sub = subSnap.exists ? subSnap.data() : null;

  if (isActive(sub)) {
    const today = todayKey();
    const dailyCount = sub.dailyDate === today ? sub.dailyCount || 0 : 0;
    return { subscribed: true, dailyRemaining: Math.max(0, DAILY_SESSION_CAP - dailyCount) };
  }

  const trialSnap = await db.collection("trials").doc(userId).get();
  const trial = trialSnap.exists ? trialSnap.data() : {};
  return {
    subscribed: false,
    coachAvailable: !trial.coachUsed,
    examinerAvailable: !trial.examinerUsed,
  };
}
