import "dotenv/config"; // .env 파일을 가장 먼저 로드 (다른 모듈이 환경변수를 읽기 전에)
// server.js
// 최소 기능 백엔드: 브라우저는 이 서버만 호출하고, 이 서버가 Anthropic API 키를 들고
// Claude를 호출한다. API 키는 절대 프론트엔드 코드에 들어가지 않는다.
//
// 흐름:
//   1) 학생이 모드를 고르면 프론트가 POST /api/session/start 호출
//      -> 여기서 "1회" 소비 (무료체험: 모드별 1회 / 유료: 하루 세션 상한만 체크)
//      -> 성공 시 sessionId 발급
//   2) 그 세션 안에서 주고받는 메시지는 POST /api/chat + sessionId
//      -> 메시지마다 사용량을 다시 깎지 않고, 세션이 유효한지만 확인

import express from "express";
import cors from "cors";
import Anthropic from "@anthropic-ai/sdk";
import { COACH_PROMPT, EXAMINER_PROMPT } from "./prompts.js";
import { startSession, validateSession, getTrialStatus } from "./usage.js";
import { requireAuth } from "./auth.js";
import paymentRouter from "./payment.js";

const app = express();

// 자기 도메인만 허용. laellab.com(메인 사이트)과 app.laellab.com(이 웹앱)만 열어둔다.
const ALLOWED_ORIGINS = [
  "https://laellab.com",
  "https://www.laellab.com",
  "https://app.laellab.com",
];
// 로컬 개발/테스트 중에는 localhost도 열어준다. Vercel 배포본은 NODE_ENV=production이
// 자동으로 설정되므로 실제 서비스에는 영향 없다.
if (process.env.NODE_ENV !== "production") {
  ALLOWED_ORIGINS.push("http://localhost:3000", "http://127.0.0.1:3000");
}
app.use(
  cors({
    origin(origin, callback) {
      // origin이 없는 요청(서버 간 호출, curl 등)은 브라우저 CORS 대상이 아니므로 통과
      if (!origin || ALLOWED_ORIGINS.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error("origin_not_allowed"));
      }
    },
  })
);
app.use(express.json({ limit: "1mb" }));

// HTML 파일 서빙 — Vercel 서버리스 환경에서도 동작하도록 명시적 라우트 사용
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import { readFileSync } from "fs";
const __dirname = dirname(fileURLToPath(import.meta.url));

const HTML_FILES = ["lael-interview-app.html", "payment-success.html", "payment-fail.html"];
for (const file of HTML_FILES) {
  app.get(`/${file}`, (req, res) => {
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.send(readFileSync(join(__dirname, file), "utf8"));
  });
}

app.use(paymentRouter);

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const MODES = {
  coach: COACH_PROMPT,
  examiner: EXAMINER_PROMPT,
};

const MODEL = "claude-sonnet-5"; // 비용/품질 균형

// ---- 세션 시작: 모드 선택 화면에서 "시작하기"를 누른 시점에 호출 ----
// requireAuth를 통과해야만 여기 도달한다 — req.userId는 토큰에서 검증된 값이다.
app.post("/api/session/start", requireAuth, async (req, res) => {
  const { mode } = req.body;
  const result = await startSession(req.userId, mode);
  if (!result.allowed) {
    return res.status(402).json(result); // 402 Payment Required — 결제/체험 소진 의미로 사용
  }
  res.json({ sessionId: result.sessionId });
});

// ---- 무료체험/구독 상태 조회 (시작 화면에 "체험 1회 남음" 등을 보여줄 때 사용) ----
// 다른 사람의 상태를 조회하지 못하도록 :userId 파라미터를 없애고 토큰의 본인 것만 조회한다.
app.get("/api/usage", requireAuth, async (req, res) => {
  const status = await getTrialStatus(req.userId);
  res.json(status);
});

// ---- 대화 ----
app.post("/api/chat", requireAuth, async (req, res) => {
  try {
    const { mode, turns, sessionId } = req.body;
    const userId = req.userId;

    if (!MODES[mode]) {
      return res.status(400).json({ error: "invalid_mode" });
    }
    if (!Array.isArray(turns) || turns.length === 0 || turns[turns.length - 1].role !== "user") {
      return res.status(400).json({ error: "invalid_turns" });
    }
    if (!(await validateSession(sessionId, userId, mode))) {
      // 세션이 없거나 만료됐거나, 토큰의 본인 것이 아니거나, 다른 모드로 위조된 요청
      return res.status(403).json({ error: "invalid_session" });
    }

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    const stream = anthropic.messages.stream({
      model: MODEL,
      max_tokens: 4000,
      // 시스템 프롬프트를 캐시 대상으로 표시 — 같은 세션 안에서 반복 호출 시
      // 동일한 시스템 프롬프트 부분은 캐시 적중되어 입력 비용이 크게 줄어든다.
      system: [
        {
          type: "text",
          text: MODES[mode],
          cache_control: { type: "ephemeral" },
        },
      ],
      messages: turns,
    });

    stream.on("text", (delta) => {
      res.write(`data: ${JSON.stringify({ delta })}\n\n`);
    });

    stream.on("error", (err) => {
      console.error("anthropic stream error", err);
      res.write(`data: ${JSON.stringify({ error: "upstream_error" })}\n\n`);
      res.end();
    });

    const finalMessage = await stream.finalMessage();
    res.write(`data: ${JSON.stringify({ done: true, usage: finalMessage.usage })}\n\n`);
    res.end();
  } catch (err) {
    console.error(err);
    if (!res.headersSent) {
      res.status(500).json({ error: "server_error" });
    } else {
      res.write(`data: ${JSON.stringify({ error: "server_error" })}\n\n`);
      res.end();
    }
  }
});

// ---- 에러 핸들링 미들웨어: 처리 안 된 예외가 함수를 이상한 상태로 남기지 않도록 ----
app.use((err, req, res, next) => {
  console.error("unhandled error:", err);
  if (!res.headersSent) {
    res.status(500).json({ error: "server_error" });
  }
});

const PORT = process.env.PORT || 8787;
// Vercel은 이 파일을 함수로 실행하며 자체적으로 요청을 받는다 — 로컬 개발할 때만 직접 리슨한다.
if (!process.env.VERCEL) {
  app.listen(PORT, () => console.log(`lael backend listening on :${PORT}`));
}

export default app; // Vercel의 zero-config Express 감지가 이 export를 찾는다
