// payment.js — 토스페이먼츠 일반결제 (자동갱신 없음, 기간권 방식)
//
// 흐름:
//   1) 학생이 "1개월 구매" 버튼 클릭
//      → 프론트가 POST /api/payment/create-order 호출 (plan만 보냄, 금액은 서버가 정함)
//      → 서버가 orders/{orderId} 문서를 만들고 금액을 확정해서 돌려준다
//   2) 프론트가 그 orderId·amount로 토스 결제창(SDK)을 띄운다
//   3) 결제 성공 시 토스가 successUrl로 리다이렉트 (paymentKey, orderId, amount 쿼리 포함)
//   4) 그 페이지가 POST /api/payment/confirm 호출
//      → 서버가 저장해둔 order와 대조(금액 위변조 방지) 후 토스 승인 API 호출
//      → 승인되면 subscriptions 문서에 expiresAt 기록 (여기서 "유료화"가 실제로 일어남)
//
// 자동갱신은 하지 않는다 — 기간이 끝나면 subscriptions.expiresAt이 지나 다시 무료체험/
// 미구독 상태로 돌아가고, 학생이 원하면 같은 흐름으로 다시 결제한다.

import express from "express";
import { requireAuth, db } from "./auth.js";
import { FieldValue } from "firebase-admin/firestore";

const router = express.Router();

// TODO: 실제 판매 시작 전 최종 확정 필요 — 아래는 제안 값입니다 (시장 비교: 유료 AI
// 모의면접 서비스는 회당 15,000~20,000원 수준 vs 무제한 월 구독; 사이트 내부 정합성:
// 1개월은 전자책 79,000원과 동일선상, 3개월은 패키지 299,000원과 충분한 차이 유지).
const PLAN_CONFIG = {
  "1m": { amountKRW: 79000, days: 30, label: "1개월 이용권" },
  "2m": { amountKRW: 139000, days: 60, label: "2개월 이용권" },
  "3m": { amountKRW: 189000, days: 90, label: "3개월 이용권" },
};

const TOSS_SECRET_KEY = process.env.TOSS_SECRET_KEY;
const TOSS_AUTH_HEADER =
  "Basic " + Buffer.from(`${TOSS_SECRET_KEY}:`).toString("base64");

// ---- 1) 주문 생성: 결제창을 띄우기 전에 서버가 먼저 금액을 확정한다 ----
router.post("/api/payment/create-order", requireAuth, async (req, res) => {
  const { plan } = req.body;
  const config = PLAN_CONFIG[plan];
  if (!config) return res.status(400).json({ error: "invalid_plan" });

  const orderId = `lael_${req.userId}_${Date.now()}`; // 토스 orderId는 상점에서 고유하게 관리
  await db.collection("orders").doc(orderId).set({
    userId: req.userId,
    plan,
    amount: config.amountKRW,
    status: "pending",
    createdAt: FieldValue.serverTimestamp(),
  });

  res.json({
    orderId,
    amount: config.amountKRW,
    orderName: config.label,
  });
});

// ---- 2) 결제 승인: successUrl 페이지가 리다이렉트 직후 호출 ----
router.post("/api/payment/confirm", requireAuth, async (req, res) => {
  const { paymentKey, orderId, amount } = req.body;
  if (!paymentKey || !orderId || !amount) {
    return res.status(400).json({ error: "invalid_request" });
  }

  const orderRef = db.collection("orders").doc(orderId);
  const orderSnap = await orderRef.get();
  if (!orderSnap.exists) return res.status(404).json({ error: "order_not_found" });

  const order = orderSnap.data();

  // ---- 위변조 방지: 이 주문이 진짜 이 사용자 것이고, 금액이 우리가 정한 그대로인지 확인 ----
  if (order.userId !== req.userId) {
    return res.status(403).json({ error: "order_user_mismatch" });
  }
  if (order.status === "done") {
    return res.status(409).json({ error: "already_confirmed" });
  }
  if (Number(amount) !== Number(order.amount)) {
    return res.status(400).json({ error: "amount_mismatch" });
  }

  // ---- 토스페이먼츠 결제 승인 API 호출 ----
  let tossResult;
  try {
    const tossResp = await fetch("https://api.tosspayments.com/v1/payments/confirm", {
      method: "POST",
      headers: {
        Authorization: TOSS_AUTH_HEADER,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ paymentKey, orderId, amount: Number(amount) }),
    });
    tossResult = await tossResp.json();
    if (!tossResp.ok) {
      await orderRef.update({ status: "failed", failReason: tossResult.message || "unknown" });
      return res.status(402).json({ error: "toss_confirm_failed", detail: tossResult });
    }
  } catch (e) {
    return res.status(500).json({ error: "toss_request_failed" });
  }

  // ---- 승인 성공: 여기서 실제로 구독이 활성화된다 ----
  const config = PLAN_CONFIG[order.plan];
  const expiresAt = new Date(Date.now() + config.days * 24 * 60 * 60 * 1000);

  await db.collection("subscriptions").doc(req.userId).set(
    {
      plan: order.plan,
      startedAt: FieldValue.serverTimestamp(),
      expiresAt,
      dailyCount: 0,
      dailyDate: null,
      paymentProviderId: paymentKey,
    },
    { merge: true }
  );

  await orderRef.update({ status: "done", paymentKey, confirmedAt: FieldValue.serverTimestamp() });

  res.json({ success: true, expiresAt });
});

// ---- 3) 결제 취소/이탈 처리: failUrl 페이지, 또는 사용자가 결제창을 닫고 나갔을 때 ----
router.post("/api/payment/cancel-order", requireAuth, async (req, res) => {
  const { orderId } = req.body;
  if (!orderId) return res.status(400).json({ error: "invalid_request" });

  const orderRef = db.collection("orders").doc(orderId);
  const orderSnap = await orderRef.get();
  if (!orderSnap.exists) return res.status(404).json({ error: "order_not_found" });

  const order = orderSnap.data();
  if (order.userId !== req.userId) {
    return res.status(403).json({ error: "order_user_mismatch" });
  }
  if (order.status === "pending") {
    await orderRef.update({ status: "cancelled" });
  }
  res.json({ ok: true });
});

// ---- 안전망: failUrl도 못 타고 그냥 탭을 닫아버린 주문 정리 ----
// (cancel-order로 대부분 처리되지만, 이건 그마저도 놓친 경우를 위한 보험이다.)
const STALE_AFTER_MS = 60 * 60 * 1000; // 1시간 지나도 pending이면 방치된 주문으로 간주

async function cleanupStaleOrders() {
  const cutoff = new Date(Date.now() - STALE_AFTER_MS);
  const snap = await db
    .collection("orders")
    .where("status", "==", "pending")
    .where("createdAt", "<", cutoff)
    .limit(100)
    .get();

  if (snap.empty) return;
  const batch = db.batch();
  snap.forEach((doc) => batch.update(doc.ref, { status: "expired" }));
  await batch.commit();
  console.log(`cleanupStaleOrders: ${snap.size}건 정리`);
}

// 서버가 떠 있는 동안 1시간마다 정리. 별도 스케줄러(Cloud Functions 등) 없이
// 이 프로세스 안에서 도는 안전망이므로, 서버 재시작이 잦으면 누락될 수 있다 —
// 치명적이지 않다(구독에 영향 없는 orders 컬렉션 정리용).
setInterval(cleanupStaleOrders, STALE_AFTER_MS);

export default router;
