# Firestore 설정 (SQL 스키마 대신)

Firestore는 스키마를 미리 만들 필요가 없다 — `usage.js`가 처음 쓰기 시점에
컬렉션/문서를 알아서 만든다. 콘솔에서 할 일은 두 가지뿐이다.

## 1. 서비스 계정 키 발급

Firebase 콘솔 > 프로젝트 설정 > 서비스 계정 탭 > "새 비공개 키 생성"
다운로드된 JSON 안의 `project_id`, `client_email`, `private_key` 세 값을
`.env`의 `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY`에 옮긴다.

## 2. sessions 컬렉션 TTL 정책 (권장, 필수는 아님)

세션 문서는 발급 후 2시간 뒤엔 의미가 없어진다. 그냥 둬도 동작에는 문제없지만
계속 쌓이므로, Firestore 콘솔 > 해당 데이터베이스 > TTL 정책에서
컬렉션 `sessions`, 필드 `expiresAt`을 지정해두면 자동으로 정리된다.

## Firestore 보안 규칙

서버는 `firebase-admin`(관리자 SDK)으로 접근하므로 보안 규칙의 영향을 받지 않는다.
다만 클라이언트(브라우저)가 `trials`/`subscriptions`/`sessions`를 직접 읽거나 쓰지
못하도록 기존 `firestore.rules`에 아래를 추가해 명시적으로 막아두는 것을 권장한다.

```
match /trials/{userId} { allow read, write: if false; }
match /subscriptions/{userId} { allow read, write: if false; }
match /sessions/{sessionId} { allow read, write: if false; }
match /orders/{orderId} { allow read, write: if false; }
```

(라엘랩 사이트가 이미 다른 컬렉션에 쓰고 있는 규칙 파일이 있을 것이므로, 그 파일에
위 4줄만 추가하면 된다. 전체를 덮어쓰지 말 것.)

## 복합 색인(composite index) 필요

`payment.js`의 정리 작업(`cleanupStaleOrders`)은 `orders` 컬렉션에
`status == 'pending'` AND `createdAt < 기준시각` 두 조건을 같이 거는 쿼리를 쓴다.
Firestore는 이런 복합 조건에 색인이 미리 있어야 한다. 서버를 처음 띄우고 1시간 뒤
이 쿼리가 처음 실행될 때 에러 메시지에 색인 생성 링크가 함께 뜨는데, 그 링크를 눌러
한 번 만들어두면 그 뒤로는 문제없이 동작한다.
