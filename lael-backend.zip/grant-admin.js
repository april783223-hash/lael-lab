// 관리자 계정에 무제한 구독 추가 스크립트
import "dotenv/config";
import admin from "firebase-admin";
import { readFileSync } from "fs";

// Firebase 초기화
const sa = JSON.parse(readFileSync(process.env.GOOGLE_APPLICATION_CREDENTIALS, "utf8"));
admin.initializeApp({ credential: admin.credential.cert(sa) });

const db = admin.firestore();
const auth = admin.auth();

async function grantUnlimited(email) {
  // 이메일로 uid 조회
  const user = await auth.getUserByEmail(email);
  console.log(`Found user: ${user.email} (uid: ${user.uid})`);

  // 10년짜리 구독 등록
  const expiresAt = new Date();
  expiresAt.setFullYear(expiresAt.getFullYear() + 10);

  await db.collection("subscriptions").doc(user.uid).set({
    plan: "admin_unlimited",
    startedAt: admin.firestore.FieldValue.serverTimestamp(),
    expiresAt,
    dailyCount: 0,
    dailyDate: "",
    paymentProviderId: "admin_grant",
  });

  console.log(`✅ ${email} → 무제한 구독 등록 완료 (만료: ${expiresAt.toISOString()})`);

  // 무료체험 기록도 리셋
  await db.collection("trials").doc(user.uid).delete().catch(() => {});
  console.log(`✅ 무료체험 기록 초기화 완료`);
}

grantUnlimited("april783223@gmail.com").then(() => process.exit(0));
