# 결제 흐름 로컬 테스트 (test-harness)

laellab.com에 실제로 연결하기 전에, 백엔드의 결제 로직(`payment.js`)만 따로 검증하는 방법.
이 폴더의 3개 HTML은 **테스트 전용**이며 실제 사이트에 올리는 코드가 아니다.

## 1. 백엔드를 로컬에서 띄운다

```
cd lael-backend
npm install
cp .env.example .env
# .env에 최소한 이것만 채우면 됨: ANTHROPIC_API_KEY, FIREBASE_*, TOSS_SECRET_KEY(test_sk_...)
npm start
```
`http://localhost:8787`에서 뜬다.

## 2. 이 test-harness 폴더를 정적 서버로 띄운다

파일을 그냥 더블클릭(`file://`)해서 열면 토스 결제창 리다이렉트가 정상 동작하지 않는다.
반드시 http 서버로 띄울 것:

```
npx serve test-harness -l 3000
```
`http://localhost:3000/test-payment.html`로 접속.

## 3. Firebase ID 토큰 준비

`/api/payment/*`는 로그인을 요구한다. laellab.com에서 실제로 로그인한 뒤, 브라우저
개발자도구 콘솔(F12)에 아래를 입력해서 나온 값을 복사한다:

```javascript
firebase.auth().currentUser.getIdToken().then(t => console.log(t))
```

(사이트가 Firebase v9 모듈 방식이면 콘솔에서 바로 이 호출이 안 될 수 있다 — 그때는
`frontend-firebase-token.js`의 `getIdToken()`을 임시로 콘솔에서 호출하거나, 페이지 안에
`console.log(await getIdToken())` 한 줄을 임시로 추가해서 확인한다.)

## 4. 테스트 진행

1. `test-payment.html`에 API_BASE(`http://localhost:8787`), TOSS_CLIENT_KEY(`test_ck_...`),
   방금 복사한 ID 토큰을 채운다.
2. 플랜 버튼 클릭 → 토스 결제창이 뜬다.
3. 테스트 키 환경에서는 실제 카드 정보를 넣어도 승인만 될 뿐 출금되지 않는다. 아무
   유효한 형식의 카드번호로 진행해도 된다.
4. 결제 완료 → `test-payment-success.html`로 리다이렉트되며 `/api/payment/confirm` 결과가
   화면에 그대로 찍힌다.
5. Firebase 콘솔의 Firestore에서 `subscriptions/{내 uid}` 문서에 `expiresAt`이 제대로
   찍혔는지 확인한다.
6. 결제창에서 취소를 누르면 `test-payment-fail.html`로 가서 `cancel-order`가 호출되는지도
   확인한다.

## 확인이 끝나면

이 `test-harness` 폴더는 배포하지 않는다. 실제 laellab.com 통합은
`frontend-toss-checkout.js`의 `startPurchase()` / `confirmPaymentFromUrl()` /
`cancelOrderFromUrl()`을 실제 사이트의 버튼과 `payment-success.html` /
`payment-fail.html`에 연결하는 방식으로 진행한다.
