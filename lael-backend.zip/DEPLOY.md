# Vercel 배포 가이드

## ⚠️ 요금제부터 확인: Hobby(무료) 플랜으로는 배포하면 안 됩니다

Vercel의 Hobby(무료) 플랜은 **약관상 상업적 용도(수익을 내는 서비스)를 금지**합니다.
이 앱은 결제를 받는 상용 서비스이므로 **Pro 플랜($20/월)**이 필요합니다. laellab.com
메인 사이트가 이미 Vercel에 있다면 같은 팀/프로젝트에 이 백엔드를 추가하는 것으로
충분하고, 요금이 크게 늘지 않을 수 있습니다 — 다만 별도 프로젝트라면 새로 Pro를
구독해야 합니다.

## 함수 실행 시간 제한 — 왜 중요한가

이 서버의 `/api/chat`은 Claude 응답이 끝날 때까지 연결을 유지하는 스트리밍 엔드포인트다.
Vercel 함수는 실행 시간 제한이 있고, 이 제한을 넘기면 응답이 중간에 끊긴다.

| 플랜 | 기본 제한 | 최대로 늘릴 수 있는 값 |
|---|---|---|
| Hobby | 10초 | 60초 (그나마도 상업적 용도 금지라 우리는 못 씀) |
| Pro | 60초 | 300초(5분) |

`vercel.json`에 `maxDuration: 60`으로 이미 설정해뒀다. 코치/면접관 모드의 답변은
구조화된 텍스트라 길 때도 대부분 60초 안에 끝나지만, 만약 실제 운영 중 타임아웃
로그가 보이면 Pro 플랜 한도 안에서 120~180으로 올리면 된다(숫자를 올릴수록 한 요청이
오래 걸릴 때 서버 비용도 그만큼 늘어난다는 점은 감안할 것).

## 배포 절차

1. Vercel 계정이 Pro인지 확인 (또는 laellab.com이 이미 쓰는 팀에 Pro가 적용돼 있는지)
2. 이 폴더(`lael-backend`)를 별도 Git 저장소로 만들거나, 기존 저장소의 하위 폴더로 둔다
3. Vercel CLI 설치 후 이 폴더에서:
   ```
   npm i -g vercel
   vercel link
   ```
4. 환경변수 등록 (터미널에서 하나씩, 또는 Vercel 대시보드 > 프로젝트 > Settings >
   Environment Variables에서 직접 입력해도 된다):
   ```
   vercel env add ANTHROPIC_API_KEY
   vercel env add FIREBASE_PROJECT_ID
   vercel env add FIREBASE_CLIENT_EMAIL
   vercel env add FIREBASE_PRIVATE_KEY
   vercel env add TOSS_SECRET_KEY
   ```
   `FIREBASE_PRIVATE_KEY`는 여러 줄 값이라 CLI에 붙여넣을 때 줄바꿈이 깨지기 쉽다.
   문제가 생기면 대시보드 UI에서 값을 붙여넣는 편이 안전하다.
5. 배포:
   ```
   vercel --prod
   ```
6. 발급된 도메인(예: `lael-backend.vercel.app`)을 `app.laellab.com`으로 연결하고
   싶다면 Vercel 대시보드 > Domains에서 커스텀 도메인을 추가한다.
7. `lael-interview-app.html`, `payment-success.html`, `payment-fail.html` 세 파일의
   `API_BASE` 상수를 실제 배포 주소로 바꾼다.

## 배포 후 확인할 것

- `/api/chat`으로 실제 대화를 시도해서 스트리밍이 끊기지 않고 끝까지 오는지 확인
- Vercel 대시보드 > Observability에서 함수 실행 시간이 60초에 자주 근접하는지 확인
  (근접한다면 `maxDuration`을 올리거나, `max_tokens`를 줄여 응답 길이 자체를 낮추는
  방법도 있다)
- `cors` 설정의 `ALLOWED_ORIGINS`에 실제 배포된 프론트엔드 도메인이 들어있는지 재확인
