// auth.js
//
// laellab.com이 이미 쓰고 있는 것과 같은 Firebase 프로젝트를 서버에서도 사용한다.
// 별도 인증 시스템을 새로 만들지 않는다 — 이미 로그인한 기존 고객이 그대로 쓸 수 있어야 하기 때문.
//
// 초기화 방식:
//   1) GOOGLE_APPLICATION_CREDENTIALS 환경변수에 서비스 계정 JSON 경로를 넣거나,
//   2) .env에 FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY를 넣는다.
//   (이 키는 관리자 권한이므로 서버에만 두고 절대 프론트에 노출하지 않는다.)

import admin from "firebase-admin";
import { readFileSync } from "fs";

if (!admin.apps.length) {
  let credential;

  // 방법 1: GOOGLE_APPLICATION_CREDENTIALS 환경변수 (서비스 계정 JSON 파일 경로)
  // Vercel이 아닌 로컬 환경에서 가장 간편한 방법
  if (process.env.GOOGLE_APPLICATION_CREDENTIALS) {
    try {
      const sa = JSON.parse(readFileSync(process.env.GOOGLE_APPLICATION_CREDENTIALS, "utf8"));
      credential = admin.credential.cert(sa);
      console.log("[AUTH] Firebase 초기화: JSON 파일 사용 (" + sa.project_id + ")");
    } catch (e) {
      console.error("[AUTH] JSON 파일 로드 실패:", e.message);
    }
  }

  // 방법 2: .env 환경변수 (Vercel 배포 시 사용)
  if (!credential && process.env.FIREBASE_PROJECT_ID) {
    credential = admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      // .env에 여러 줄 키를 한 줄로 넣을 때 \n이 문자 그대로 들어가므로 실제 개행으로 되돌린다
      privateKey: (process.env.FIREBASE_PRIVATE_KEY || "").replace(/\\n/g, "\n"),
    });
    console.log("[AUTH] Firebase 초기화: 환경변수 사용 (" + process.env.FIREBASE_PROJECT_ID + ")");
  }

  if (!credential) {
    console.error("[AUTH] ❌ Firebase 인증 정보가 없습니다!");
    console.error("  → .env에 GOOGLE_APPLICATION_CREDENTIALS=/path/to/serviceAccountKey.json 을 추가하거나");
    console.error("  → FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY를 설정하세요.");
    process.exit(1);
  }

  admin.initializeApp({ credential });
}

export async function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: "no_token" });
  }

  try {
    const decoded = await admin.auth().verifyIdToken(token);
    req.userId = decoded.uid; // laellab.com 기존 로그인의 Firebase uid와 동일한 값
    next();
  } catch (e) {
    return res.status(401).json({ error: "invalid_token" });
  }
}

export const db = admin.firestore();
